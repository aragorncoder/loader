# xZulu Loader made by xmasterx and aragornN
Bu loader C# .NET uzantılarıyla yapılmıştır

Bunu kendi hilesine loader olarak editleyip kullanların credit vermesi önerilir

Edit yapıp kullanların credit vermediyse telif atılacaktır
